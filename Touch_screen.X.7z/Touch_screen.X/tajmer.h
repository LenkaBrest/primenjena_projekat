/* 
 * File:   tajmer.h
 * Author: Lenka
 *
 * Created on December 21, 2020, 2:12 PM
 */

#ifndef TAJMER_H
#define	TAJMER_H

#ifdef	__cplusplus
extern "C" {
#endif



void Init_T1(void);
void Init_T3(void);


#ifdef	__cplusplus
}
#endif

#endif	/* TAJMER_H */

